import numpy
from sklearn import linear_model
from get_data import x, y

logr = linear_model.LogisticRegression()
logr.fit(x, y)

log_odds = logr.coef_ 
odds = numpy.exp(log_odds)

predicted = logr.predict(numpy.array([3.6, 15.5, 0, 0, 11]).reshape(1,5))

def logit2prob(logr, X):
  log_odds = 0
  for i in range(0, 4):
    log_odds += logr.coef_[0][i] * X[0][i]
  log_odds += logr.intercept_
  
  odds = numpy.exp(log_odds)
  probability = odds / (1 + odds)
  return(probability[0])
print("=====================================================")
print("Raining percentage : ", logit2prob(logr, numpy.array([3.6, 15.5, 0, 0, 11]).reshape(1,5)))
print("Raining percentage : ", logit2prob(logr, numpy.array([20.4, 37.6, 0, 0, 54]).reshape(1,5)))
print("Raining percentage : ", logit2prob(logr, numpy.array([20.9, 33.6, 0.4, 0, 50]).reshape(1,5)))
print(logr.coef_)
print(logr.intercept_)