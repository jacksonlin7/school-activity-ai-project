import pandas as pd

df = pd.read_csv('./dataset.csv')
y = df[['RainToday']]
x = df[['MinTemp', 'MaxTemp', 'Rainfall', 'Sunshine', 'WindGustSpeed']]